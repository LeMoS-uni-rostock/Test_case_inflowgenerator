import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec	# grid for figures
import sys
import os
import shutil
import csv
from tabulate import tabulate
import pandas as pd

# read plotting function script
AiF_main_directory = "/home/henry/Daten/AIF_Projekt/"
exec(open(AiF_main_directory +"python_scripts/functions_plotting.py").read())


# script to generate the turbulent input files for inflow generator Kroeger2018 (fortran version)
#
# this scripts calculates the U-profile, the Reynolds stresses and the length scales from analytical relations
#	and writes them into files readable for the inflow generator


#### plotting
## plottingmarker_style
font_size = 12
line_width = 1
exec(open("/home/henry/Daten/AIF_Projekt/python_scripts/latex_plot_params.py").read())
fig_size = [fig_width,fig_height]
plt.rcParams["figure.figsize"] = fig_size

def defaultPlot(ax,x,y,i,legendName):
	ax.plot(x,y, marker_style[i], markerfacecolor=line_color[i], markeredgecolor=line_color[i], 
			linestyle='--', dashes=dash_list[0], markevery=5, color=line_color[i], alpha=1.0, label=legendName)

def defaultPlot_b(ax,x,y,i,legendName):
	ax.plot(x,y, marker_style[i], markerfacecolor=line_color[i], markeredgecolor=line_color[i], 
			linestyle='--', dashes=dash_list[0], markevery=5, color=line_color[i], alpha=0.3, label=legendName)



#################################################################
# # # # # # # # # # # #   U   # # # # # # # # # # # # # # # # # # 
#################################################################


# reference values for Velocity and Lii fileds
Uref = 4.8
zref = 70
z0 = 0.06				# roughness length
kappa = 0.41			
pi = 3.14159
nu = 1.5e-5
Cmu = 0.09



### calc Ux 
z_p = np.arange(0,610,0.2)
z = np.zeros(len(z_p)-1)	# cell center values
for i in range(len(z_p)-1):
	z[i] = z_p[i]+0.5*(z_p[i+1]-z_p[i])

Ux_p = Uref*(np.log((z_p+z0)/z0))/(np.log((zref+z0)/z0))
Ux_log = Uref*(np.log((z+z0)/z0))/(np.log((zref+z0)/z0))

#

# plot u profile
fig_size = [fig_width,fig_height]
plt.rcParams["figure.figsize"] = fig_size
fig, ax = plt.subplots(1,1 )
plt.subplots_adjust(left=0.1, right=0.98, top=0.92, bottom=0.12)
defaultPlot(ax,Ux_log,z,0,"$U_x^\\mathrm{log}$") 

ax.set_ylabel('$z$ in m')
ax.set_xlabel('$U_x$ in m/s')
#ax.set_xscale('log')
plt.yscale('log')
lines, labels = fig.axes[-1].get_legend_handles_labels()
fig.legend(lines, labels, loc = 'upper center', bbox_to_anchor=(0.5, 0.99), ncol=4).get_frame().set_lw(0.5)
ax.grid(linestyle='--',alpha=0.5)
#
#plt.show()
fig.savefig( "U.pdf")




#################################################################
# # # # # # # # # # # #  Rij  # # # # # # # # # # # # # # # # # # 
#################################################################

ustar = Uref*kappa/(np.log((zref+z0)/z0))
nut = (ustar*z*kappa)/(np.log((z+z0)/z0)) - nu

##
## Richards Hoxey
k = ustar**2/(Cmu**0.5)		

Rij = np.zeros([6,len(z)])	#	Rxx,Rxy,Rxz,Ryy,Ryz,Rzz
for i in range(len(z)):
	dUxdz = (Ux_p[i+1]-Ux_p[i])/(z_p[i+1]-z_p[i])
	dUzdx = 0
	#
	# first part (2/3 I k)
	Rij[0,i] = 2/3*k
	Rij[3,i] = 2/3*k
	Rij[5,i] = 2/3*k
	#
	# second part Sij
	#print ("check: %5.4f\t%5.4f " %(nut[i],dUxdz))
	Rij[2,i] = Rij[2,i] - 2*nut[i]*(0.5*(dUxdz+dUzdx))
#







# plot Rij profile
fig, ax = plt.subplots(1,1 )
plt.subplots_adjust(left=0.1, right=0.98, top=0.92, bottom=0.12)
#
defaultPlot_b(ax,Rij[0,:],z,0,"$R_{11}^\\mathrm{RANS}$")
# defaultPlot_b(ax,Rij[1,:],z,1,"$R_{12}^\\mathrm{RANS}$") 
defaultPlot_b(ax,Rij[2,:],z,2,"$R_{13}^\\mathrm{RANS}$") 
defaultPlot_b(ax,Rij[3,:],z,3,"$R_{22}^\\mathrm{RANS}$") 
# defaultPlot_b(ax,Rij[4,:],z,4,"$R_{23}^\\mathrm{RANS}$") 
defaultPlot_b(ax,Rij[5,:],z,5,"$R_{33}^\\mathrm{RANS}$") 


ax.set_ylabel('$z$ in m')
ax.set_xlabel('$<u_i u_j> $ in m$^2$/s$^2$')
ax.grid(linestyle='--',alpha=0.5)
ax.legend(loc='upper right',bbox_to_anchor=(1.0, 1.0)).get_frame().set_lw(0.5)
fig.savefig( "R" + ".pdf")





### calc Lij
ustar = Uref*kappa/(np.log((zref+z0)/z0))
hstar = 1.e4/6. * ustar
print ("ustar = ", ustar)
#
## L_ux from fig. 13 in counihan 1975
# L_11 =	get_Lux_Counihan(z,z0_compare[k])
# L_11 = get_Lux_Counihan_decrease(z,z0)
L_11 = get_Lux_Counihan_const(z_p,z0)
#
#
L_13 = L_11 * (0.5-0.34*np.exp(-35.0*(z_p/hstar)**1.7))
L_12 = L_11 * 0.16 + 0.68*L_13
#
L_21 = 0.5*L_11*0.75**3.
L_22 = 2.0 * L_12*0.75**3.
L_23 = L_13 * 0.75**3.

L_31 = 0.5*L_11*0.5**3.
L_32 = L_12*0.5**3.
L_33 = 2.0 * L_13*0.5**3.







with open("U.dat", 'w') as f:
	#f.write(" %8.4f \t %8.4f \t %8.4f \t %8.4f \n" %(0,0,0,0))
	for i in range(len(z_p)):
		f.write(" %8.4f \t %8.4f \t %8.4f \t %8.4f \n"% (z_p[i], Ux_p[i],0,0))


with open("R_ij.dat", 'w') as f:
	for i in range(len(z)):
		f.write(" %8.4f \t %8.4f \t %8.4f \t %8.4f \t %8.4f \t %8.4f \t %8.4f  \n"
			%(z[i], Rij[0,i], Rij[1,i], Rij[2,i], Rij[3,i], Rij[4,i], Rij[5,i]))
#
with open("Lii.dat", 'w') as f:
	#f.write(" %8.4f \t %8.4f \t %8.4f \t %8.4f  \n" 
	#	%(0,0,0,0))
	for i in range(len(z_p)):
		f.write(" %8.4f \t  %8.4f \t %8.4f \t %8.4f  \n"
			%(z_p[i], L_11[i], L_22[i], L_33[i] ))




